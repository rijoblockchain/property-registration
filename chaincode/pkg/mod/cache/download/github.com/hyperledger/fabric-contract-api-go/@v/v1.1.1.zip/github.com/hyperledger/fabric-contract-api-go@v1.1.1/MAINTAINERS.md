Maintainers
===========

| Name                      | GitHub           | Chat           | email                               |
|---------------------------|------------------|----------------|-------------------------------------|
| Andrew Hurt               | awjh-ibm         | awjh-ibm       | andrew.hurt1@ibm.com                |
| James Taylor              | jt-nti           |   jtonline     | jamest@uk.ibm.com                   |

Also: Please see the [Release Manager section](https://github.com/hyperledger/fabric/blob/master/MAINTAINERS.md)